# NE Password Audit

Identify NEs that don't share the same password and force update the changes.

## Artifact Workflows

- ne-password-audit
- ne-password-update

## Contact

<siva.sivakumar@nokia.com>
